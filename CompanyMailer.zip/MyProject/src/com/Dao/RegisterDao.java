package com.Dao;

import java.sql.*;
import java.util.Formatter;
public class RegisterDao {


	public static int save(String name,String email,String password,String gender,String addressLine,String city,String state,String country,String contact){
		int status=0;
		
		try{
			Connection con=ConProvider.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into REGISTRATION_USER(id,name,email,password,gender,addressLine,city,state,country,contact) values(REGISTRATION_ID.NEXTVAL,?,?,?,?,?,?,?,?,?)");
			ps.setString(1,name);
			ps.setString(2,email);
			ps.setString(3,password);
			ps.setString(4,gender);
			ps.setString(5,addressLine);
			ps.setString(6,city);
			ps.setString(7,state);
			ps.setString(8,country);
			ps.setString(9,contact);
			
			status=ps.executeUpdate();
						
		}catch(Exception e){System.out.println(e);}
		
		
		
		return status;
	}

}
