package com.Dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.Formatter;

import com.model.Details;
import com.model.Login;
public class RegisterDao {


	public static int save(String name,String email,String password,String gender,String addressLine,String city,String state,String country,String contact){
		int status=0;
		
		try{
			Connection con=ConProvider.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into REGISTRATION_USER(id,name,email,password,gender,addressLine,city,state,country,contact) values(REGISTRATION_ID.NEXTVAL,?,?,?,?,?,?,?,?,?)");
			ps.setString(1,name);
			ps.setString(2,email);
			ps.setString(3,password);
			ps.setString(4,gender);
			ps.setString(5,addressLine);
			ps.setString(6,city);
			ps.setString(7,state);
			ps.setString(8,country);
			ps.setString(9,contact);
			
			status=ps.executeUpdate();
						
		}catch(Exception e){System.out.println(e);}
		
		
		
		return status;
	}

	public void save(ArrayList<Details> list) {
		// TODO Auto-generated method stub
		try{
			Login l = new Login();
			Details d = new Details(l);
			Connection con=ConProvider.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into REGISTRATION_USER  values(REGISTRATION_ID.NEXTVAL,?,?,?,?,?,?,?,?,?)");
			ps.setString(1,d.getName());
			ps.setString(2,d.getEmail());
			ps.setString(3,d.getPassword());
			ps.setString(4,d.getGender());
			ps.setString(5,d.addressLine);
			ps.setString(6,city);
			ps.setString(7,state);
			ps.setString(8,country);
			ps.setString(9,contact);
			
			status=ps.executeUpdate();
						
		}catch(Exception e){System.out.println(e);}
		
		
		
		return status;
	}
		
	}

}
